# Women-Clothing-Review-
Applying Sentiment Analysis at the texts and further Machine Learning to the dataset. Visualizations using Tableau. 
